# Development Plan — Gia sư từ vựng

**Nguồn:** `project-overview-prd.md`, `design-guidelines.md`  
**Trạng thái:** Ready for repository discovery  
**Ngày:** 2026-08-21  

## 1. Mục tiêu triển khai

- **MVP cần giao:** Mobile App ưu tiên và Web responsive giúp người mới học tiếng Trung học từ vựng HSK 1–2 theo luồng: Tổng quan hôm nay → Học từ mới → Kiểm tra → Ôn lại bằng SRS → Thống kê.
- **Core user flow:** Mở sản phẩm, xem việc học hôm nay, bắt đầu học, kiểm tra, ôn các từ cần củng cố và xem tiến độ.
- **Điều kiện hoàn tất:** Core flow chạy đầu-cuối trên Mobile và Web; có loading/empty/error/success; test, lint và build của repository chạy được; có bản thử nghiệm cho người dùng mục tiêu.

## 2. Ràng buộc và nguyên tắc

- Không mở rộng scope ngoài PRD.
- Phạm vi nội dung ban đầu: HSK 1–2.
- Mobile ưu tiên, Web responsive.
- UI bám design guideline: thân thiện, rõ ràng, tạo động lực; xanh navy + xanh lá; nền sáng; icon bo tròn; panda.
- Mỗi vùng quyết định chỉ có một primary CTA.
- Không dùng màu làm tín hiệu duy nhất.
- Không bịa cấu trúc repository, file/module hay stack hiện tại.
- Schema, breaking change và thao tác phá hủy phải được xác nhận trước nếu có rủi ro.
- Điểm PRD chưa chốt phải giữ thành open decision.

## 3. Repository discovery gate

Trước khi sửa code, Codex phải:

- [ ] Đọc ba tài liệu dự án.
- [ ] Kiểm tra stack, package manager và lệnh chạy thực tế.
- [ ] Xác định module/file liên quan đến app, vocabulary, quiz, SRS và stats.
- [ ] Xác định test, lint, build và deploy command.
- [ ] Kiểm tra routing, state, data fetching và persistence hiện có.
- [ ] Xác định authentication/account hiện có.
- [ ] Xác định nguồn dữ liệu HSK 1–2.
- [ ] Báo mọi mâu thuẫn giữa repo và tài liệu trước khi đổi public contract hoặc schema.

## 4. Technical approach

- **Stack hiện có:** `<Codex xác nhận sau khi khảo sát repo>`
- **Stack đề xuất nếu greenfield:** Stack TypeScript có thể chia sẻ logic giữa các nền tảng; framework cụ thể **cần xác nhận sau khi Codex khảo sát repo**.
- **Kiến trúc tổng thể:** Tách UI, application/domain logic và data/persistence ở mức vừa đủ cho MVP.
- **Lý do:** SRS và progress cần được kiểm thử độc lập với UI, nhưng MVP không cần kiến trúc phức tạp.
- **Trade-off:** Ưu tiên đơn giản, dễ hiểu, dễ sửa; nếu repo đã có pattern tốt thì tái sử dụng.

## 5. Data model

| Entity | Field chính | Quan hệ/ràng buộc | Ghi chú |
|---|---|---|---|
| VocabularyItem | `id`, `hanzi`, `pinyin`, `meaning`, `level` | `level` thuộc HSK 1–2 | Nguồn dữ liệu chưa chốt |
| LearningProgress | `vocabularyItemId`, `status`, `lastReviewedAt`, `nextReviewAt` | Liên kết VocabularyItem | Phục vụ SRS/progress |
| QuizAttempt | `id`, `vocabularyItemId`, `answer`, `isCorrect`, `createdAt` | Liên kết VocabularyItem | Ghi nhận kết quả |
| LearningSession | `id`, `startedAt`, `completedAt`, `type`, `status` | Có thể liên kết item/attempt | Theo dõi phiên |
| User | `<Codex xác nhận sau khi khảo sát repo>` | Chỉ cần nếu có account/persistence theo user | PRD chưa chốt |

**Open decisions:** Quy tắc SRS, authentication và persistence giữa thiết bị chưa được PRD chốt.

## 6. API và interface contracts

| Interface | Input | Output | Lỗi/validation |
|---|---|---|---|
| `getTodayOverview` | user/session context nếu cần | Nội dung hôm nay, progress | empty/error |
| `getVocabularyItems` | level, session context | VocabularyItem[] | Chỉ HSK 1–2 |
| `submitQuizAnswer` | item, answer | `isCorrect`, feedback, progress | Input thiếu/không hợp lệ |
| `getDueReviews` | user/session context | Items đến hạn | empty |
| `submitReview` | item, review result | Updated SRS/progress | Input không hợp lệ |
| `getStats` | user/session context | Statistics summary | empty/error |

Đây là contract logic MVP, không phải cam kết REST endpoint. Codex map vào architecture thực tế sau discovery.

## 7. Component/module architecture

| Module/component | Trách nhiệm | Phụ thuộc | File dự kiến |
|---|---|---|---|
| Today Overview | Nhiệm vụ và CTA | Progress/session | `<Codex xác nhận sau khi khảo sát repo>` |
| Vocabulary Learning | Học từ mới | Vocabulary, learning state | `<Codex xác nhận sau khi khảo sát repo>` |
| Quiz | Câu hỏi và kết quả | Vocabulary, quiz logic | `<Codex xác nhận sau khi khảo sát repo>` |
| SRS Review | Item cần ôn | SRS, progress | `<Codex xác nhận sau khi khảo sát repo>` |
| Statistics | Tiến độ | Sessions, attempts, progress | `<Codex xác nhận sau khi khảo sát repo>` |
| Vocabulary data layer | Cung cấp HSK 1–2 | Data source | `<Codex xác nhận sau khi khảo sát repo>` |
| SRS domain logic | Tính item cần review | LearningProgress | `<Codex xác nhận sau khi khảo sát repo>` |
| Progress/statistics logic | Tổng hợp tiến độ | LearningSession, QuizAttempt | `<Codex xác nhận sau khi khảo sát repo>` |
| Shared UI | Button, card, progress, feedback | Design tokens | `<Codex xác nhận sau khi khảo sát repo>` |

## 8. Bản đồ phase

- [ ] Phase 0 — Repository discovery và baseline
- [ ] Phase 1 — Project foundation và data foundation
- [ ] Phase 2 — Core domain/data logic
- [ ] Phase 3 — Core user flow
- [ ] Phase 4 — UI implementation và responsive
- [ ] Phase 5 — Integration và hardening
- [ ] Phase 6 — QA, deploy thử nghiệm và feedback

## 9. Chi tiết từng phase

### Phase 0 — Repository discovery và baseline

- **Mục tiêu:** Hiểu repo trước khi sửa code.
- **Input:** Repository và tài liệu dự án.
- **Dependency:** Không có.
- **File/module dự kiến:** `<Codex xác nhận sau khi khảo sát repo>`.
- **Công việc:** Đọc tài liệu; kiểm tra stack/scripts/source; chạy baseline; xác định test/lint/build/deploy; tìm data/persistence/auth; ghi mâu thuẫn.
- **Artifact đầu ra:** Discovery note và baseline status.
- **Done criteria:** [ ] Biết stack và lệnh chạy; [ ] biết module liên quan; [ ] biết trạng thái test/lint/build; [ ] không còn đoán cấu trúc repo.
- **Cách kiểm chứng:** Chạy command thực tế và ghi evidence.
- **Rủi ro:** Repo khác giả định.
- **Handoff:** Chốt approach theo discovery.

### Phase 1 — Project foundation và data foundation

- **Mục tiêu:** Chuẩn bị nền tảng và vocabulary data.
- **Input:** Phase 0.
- **Dependency:** Phase 0.
- **File/module dự kiến:** `<Codex xác nhận sau khi khảo sát repo>`.
- **Công việc:** Chuẩn bị cấu trúc theo pattern repo; vocabulary interface; persistence phù hợp; error handling cơ bản.
- **Artifact đầu ra:** App foundation và vocabulary data layer.
- **Done criteria:** [ ] App chạy; [ ] đọc được vocabulary theo contract; [ ] validation cơ bản hoạt động.
- **Cách kiểm chứng:** Unit/integration test và chạy app.
- **Rủi ro:** Nguồn HSK 1–2 chưa sẵn sàng.
- **Handoff:** Data layer dùng được bởi core flow.

### Phase 2 — Core domain/data logic

- **Mục tiêu:** Xây logic học, quiz, progress, SRS.
- **Input:** Vocabulary data layer.
- **Dependency:** Phase 1.
- **File/module dự kiến:** `<Codex xác nhận sau khi khảo sát repo>`.
- **Công việc:** Learning session; quiz validation; progress tracking; SRS rule sau khi chốt; stats aggregation.
- **Artifact đầu ra:** Domain/application logic có test.
- **Done criteria:** [ ] Quiz đúng; [ ] progress nhất quán; [ ] SRS xác định item review theo rule; [ ] stats phản ánh hoạt động.
- **Cách kiểm chứng:** Unit tests cho đúng/sai, empty, boundary và review state.
- **Rủi ro:** SRS rule chưa chốt.
- **Handoff:** Logic có interface rõ cho UI.

### Phase 3 — Core user flow

- **Mục tiêu:** Kết nối thành flow đầu-cuối.
- **Input:** Domain logic.
- **Dependency:** Phase 2.
- **File/module dự kiến:** `<Codex xác nhận sau khi khảo sát repo>`.
- **Công việc:** Overview → học → quiz → SRS → stats.
- **Artifact đầu ra:** Core flow đầu-cuối.
- **Done criteria:** [ ] Đi hết flow; [ ] state được giữ đúng; [ ] quiz ảnh hưởng review/progress theo contract.
- **Cách kiểm chứng:** Integration test và manual E2E.
- **Rủi ro:** State mất khi chuyển màn hình/reload.
- **Handoff:** Flow hoàn chỉnh để làm UI.

### Phase 4 — UI implementation và responsive

- **Mục tiêu:** Triển khai theo design guideline.
- **Input:** Core flow + design guideline.
- **Dependency:** Phase 3.
- **File/module dự kiến:** `<Codex xác nhận sau khi khảo sát repo>`.
- **Công việc:** Overview; Vocabulary Learning; Quiz/feedback; SRS; Stats; design tokens; panda; responsive; loading/empty/error/success.
- **Artifact đầu ra:** UI MVP responsive.
- **Done criteria:** [ ] Khớp guideline; [ ] mobile hoàn thành flow; [ ] desktop hoàn thành flow; [ ] accessibility checklist chính đạt.
- **Cách kiểm chứng:** Manual UI review mobile/desktop và keyboard test.
- **Rủi ro:** Cần điều chỉnh UI khi gặp dữ liệu thực.
- **Handoff:** UI + logic tích hợp.

### Phase 5 — Integration và hardening

- **Mục tiêu:** Ổn định trước thử nghiệm.
- **Input:** UI + domain logic.
- **Dependency:** Phase 4.
- **File/module dự kiến:** `<Codex xác nhận sau khi khảo sát repo>`.
- **Công việc:** Error/recovery; empty/edge cases; persistence/reload nếu cần; test/lint/build; kiểm tra secret/PII; sửa lỗi ảnh hưởng core flow.
- **Artifact đầu ra:** Build candidate.
- **Done criteria:** [ ] Core flow ổn định; [ ] không có P0 đã biết; [ ] test/lint/build đạt; [ ] recovery hoạt động.
- **Cách kiểm chứng:** Repository commands và smoke test.
- **Rủi ro:** Persistence/SRS/progress tích hợp lỗi.
- **Handoff:** Sẵn sàng deploy thử nghiệm.

### Phase 6 — QA, deploy thử nghiệm và feedback

- **Mục tiêu:** Đưa MVP cho người dùng mục tiêu thử.
- **Input:** Build candidate.
- **Dependency:** Phase 5.
- **File/module dự kiến:** `<Codex xác nhận sau khi khảo sát repo>`.
- **Công việc:** Deploy; smoke test mobile/web; cho người mới học dùng thử; ghi friction; phân loại feedback thành bug, UX issue và product assumption.
- **Artifact đầu ra:** Bản thử nghiệm và feedback log.
- **Done criteria:** [ ] Người dùng hoàn thành core flow; [ ] không có blocker; [ ] có feedback để quyết định iteration.
- **Cách kiểm chứng:** Smoke test và usability test ngắn.
- **Rủi ro:** Mẫu feedback nhỏ chưa đại diện.
- **Handoff:** Quyết định iteration tiếp theo dựa trên evidence.

## 10. Test và validation strategy

| Requirement/criterion | Loại test | Cách kiểm chứng | Evidence mong đợi |
|---|---|---|---|
| Overview có CTA | component/manual | Mở app | Test result/screenshot |
| Học HSK 1–2 | integration/manual | Hoàn thành phiên học | Session hoàn thành |
| Quiz đúng/sai | unit/integration | Test answer đúng, sai, trống | Test pass + feedback |
| SRS | unit/integration | Dùng progress state mẫu | Test pass |
| Stats | unit/integration/manual | Học xong rồi mở stats | Dữ liệu nhất quán |
| Loading/empty/error/success | component/manual | Mô phỏng từng state | State + recovery |
| Responsive | manual | Mobile + desktop | Core flow chạy cả hai |
| Accessibility | manual | Focus, contrast, touch target | Checklist |
| Build/lint/test | repository commands | Chạy command thực tế | Output thành công |

## 11. Security, privacy và reliability

- Input validation trước khi cập nhật progress/review.
- Auth chỉ triển khai nếu MVP/repo yêu cầu; chưa được PRD chốt.
- Không commit secret; dùng environment variables.
- Không thu thập dữ liệu cá nhân nếu không cần.
- Error có recovery và không làm mất trạng thái nếu persistence được dùng.
- Không log secret hoặc PII.
- SRS/progress phải có test vì ảnh hưởng trực tiếp đến giá trị cốt lõi.

## 12. Deploy và feedback loop

- **Môi trường thử nghiệm:** `<Codex xác nhận sau khi khảo sát repo>`.
- **Cấu hình:** Environment variables và data source theo repository.
- **Smoke test:** Overview → học → quiz → review → stats.
- **Ai dùng thử:** Người mới học tiếng Trung thuộc nhóm mục tiêu.
- **Feedback cần thu:** Có hiểu việc cần làm? Có hoàn thành flow? Chỗ nào khó hiểu? SRS có hữu ích? Stats có giúp hiểu tiến độ?
- **Quyết định:** Tiếp tục nếu core flow có giá trị; cải thiện nếu có friction; pivot nếu giả định giá trị chính bị bác bỏ. Không đặt ngưỡng định lượng khi chưa có evidence.

## 13. Open decisions cho Codex hoặc chủ sản phẩm

- [ ] Stack/repository architecture sau discovery.
- [ ] Nguồn dữ liệu HSK 1–2.
- [ ] Quy tắc SRS cụ thể.
- [ ] Có cần authentication không.
- [ ] Có cần persistence giữa thiết bị không.
- [ ] Môi trường deploy thử nghiệm.
- [ ] Phương án lưu trữ dữ liệu.
- [ ] Cách tạo quiz từ vocabulary data.

## 14. Definition of Done toàn MVP

- [ ] Core user flow chạy đầu-cuối.
- [ ] P0 requirements đạt success criteria.
- [ ] Loading, empty, error và success được xử lý.
- [ ] Test, lint và build chạy xanh.
- [ ] Không lộ secret hoặc PII trong code/log.
- [ ] Bản thử nghiệm có thể được người dùng mục tiêu trải nghiệm.
- [ ] Mobile và Web responsive hoàn thành core flow.
- [ ] SRS và progress có test cho trạng thái quan trọng.
- [ ] UI không có tính năng ngoài PRD.
