# Project Overview & PRD — Gia sư từ vựng

**Trạng thái:** Draft  
**Ngày:** 2026-08-21  
**Phiên bản:** MVP  

## 1. Tổng quan sản phẩm

- **Tên sản phẩm:** Gia sư từ vựng
- **Mô tả một câu:** Ứng dụng hỗ trợ người mới học tiếng Trung xây nền tảng từ vựng HSK 1–2 thông qua học từ mới, kiểm tra, ôn lại bằng SRS và theo dõi tiến độ.
- **Đối tượng người dùng:** Người mới học tiếng Trung, gồm học sinh, sinh viên và người đi làm.
- **Nền tảng:** Mobile App (ưu tiên) và Web App responsive.
- **Hành động quan trọng nhất:** Bắt đầu học từ mới.

## 2. Câu định vị MVP

> Tôi tạo ra **Gia sư từ vựng** dành cho **người mới học tiếng Trung** để giúp họ **học và ôn từ vựng HSK 1–2 một cách đều đặn**.

## 3. Người dùng và bối cảnh

- **Người dùng chính:** Người mới học tiếng Trung, gồm học sinh, sinh viên và người đi làm.
- **Tình huống sử dụng:** Học từ vựng trong các khoảng thời gian hằng ngày, trên mobile hoặc web.
- **Động lực:** Xây nền tảng từ vựng và duy trì việc học.
- **Rào cản:** Đây là các giả định cần kiểm chứng; tài liệu nguồn chưa cung cấp bằng chứng cụ thể về nguyên nhân khiến người dùng bỏ cuộc hoặc khó học.

## 4. Vấn đề cần giải quyết

- **Nỗi đau chính:** Người mới học cần một cách đơn giản để học từ mới, kiểm tra khả năng nhớ, ôn lại đúng lúc và theo dõi tiến độ.
- **Cách làm hiện tại:** `CHƯA ĐỦ DỮ LIỆU` — tài liệu nguồn chưa mô tả cách người dùng đang xử lý việc này hiện nay.
- **Vì sao cách hiện tại chưa tốt:** `CHƯA ĐỦ DỮ LIỆU` — chưa có bằng chứng được cung cấp.
- **Bằng chứng:** `CHƯA ĐỦ DỮ LIỆU`.

## 5. Job To Be Done

> Khi muốn học và củng cố từ vựng tiếng Trung, tôi muốn học từ mới, kiểm tra và ôn lại các từ cần nhớ, để xây nền tảng từ vựng HSK 1–2 và theo dõi tiến độ học.

## 6. Giá trị sản phẩm

- **Giá trị cốt lõi:** Gom việc học mới, kiểm tra, ôn SRS và theo dõi tiến độ vào một luồng học đơn giản.
- **Điểm khác biệt có thể kiểm chứng:** SRS được dùng trong core flow để đưa người học quay lại các từ cần ôn. Hiệu quả thực tế của cách này chưa được kiểm chứng.
- **Giả định quan trọng nhất:** Người mới học sẽ thấy luồng học mới → kiểm tra → ôn SRS → xem tiến độ đủ hữu ích để quay lại học thường xuyên.

## 7. Core user flow

1. Người dùng mở Gia sư từ vựng và xem tổng quan hôm nay.
2. Hệ thống hiển thị nội dung học và tiến độ liên quan.
3. Người dùng chọn **Bắt đầu học** và học từ mới HSK 1–2.
4. Người dùng thực hiện phần kiểm tra để kiểm tra khả năng nhớ.
5. Hệ thống xác định nội dung cần ôn lại bằng SRS.
6. Người dùng ôn lại các từ cần củng cố.
7. Người dùng xem thống kê và tiến độ học.

## 8. Functional requirements

### P0 — Bắt buộc cho MVP

- **FR-01 — Tổng quan hôm nay:** Khi người dùng mở sản phẩm, hệ thống phải hiển thị tổng quan việc học hôm nay và cho phép bắt đầu phiên học.
- **FR-02 — Học từ mới:** Người dùng phải có thể học các từ vựng trong phạm vi HSK 1–2 và theo dõi tiến trình của phiên học.
- **FR-03 — Kiểm tra:** Người dùng phải có thể thực hiện bài kiểm tra sau phần học từ mới và nhận feedback về kết quả.
- **FR-04 — Ôn lại bằng SRS:** Hệ thống phải hỗ trợ một luồng ôn lại các từ cần củng cố bằng SRS.
- **FR-05 — Thống kê:** Người dùng phải có thể xem tiến độ học của mình.
- **FR-06 — Responsive:** Core user flow phải sử dụng được trên Mobile App và Web App responsive.
- **FR-07 — Trạng thái giao diện:** Các luồng chính phải có trạng thái loading, empty, error và success phù hợp.

### P1 — Có thể làm sau khi P0 ổn định

- Chưa xác định. Không thêm tính năng ngoài phạm vi MVP khi chưa có nhu cầu kiểm chứng rõ ràng.

## 9. Scope

### IN — MVP làm

- Tổng quan hôm nay.
- Học từ mới HSK 1–2.
- Kiểm tra.
- Ôn lại bằng SRS.
- Thống kê tiến độ.
- Mobile App ưu tiên.
- Web App responsive.
- Các trạng thái loading, empty, error và success cần thiết cho core flow.

### OUT — Chưa làm

- Nội dung vượt ngoài phạm vi HSK 1–2.
- Các tính năng chưa xuất hiện trong MVP nguồn.
- Các tính năng mở rộng chưa có giả định cần kiểm chứng rõ ràng.

### Non-goals — Cố tình không giải quyết

- Không trở thành một nền tảng học tiếng Trung toàn diện trong MVP.
- Không mở rộng sang các kỹ năng ngoài phạm vi từ vựng.
- Không xây thêm tính năng chỉ để làm sản phẩm nhiều chức năng hơn.

## 10. Success criteria và validation

| Success criterion | Cách kiểm chứng | Tín hiệu đạt |
|---|---|---|
| Người dùng hiểu việc cần làm khi mở sản phẩm | Test với người dùng mục tiêu | Người dùng xác định được CTA bắt đầu học mà không cần hướng dẫn |
| Người dùng hoàn thành core flow | Test đầu-cuối trên mobile và web | Hoàn thành học → kiểm tra → ôn SRS → xem thống kê |
| Người dùng nhận được feedback sau kiểm tra | Manual test / usability test | Kết quả đúng/sai và bước tiếp theo được hiểu rõ |
| SRS tạo được phiên ôn | Test với dữ liệu mẫu | Có thể đưa từ cần củng cố vào luồng ôn |
| Tiến độ được cập nhật và hiển thị | Test sau một phiên học | Thống kê phản ánh được hoạt động vừa thực hiện |

**Lưu ý:** Các ngưỡng định lượng về retention, tần suất học hoặc tỷ lệ hoàn thành chưa được cung cấp, nên hiện tại ghi `CHƯA ĐỦ DỮ LIỆU`.

## 11. Edge cases quan trọng

- Khi input/đáp án trống hoặc không hợp lệ: hiển thị validation rõ ràng và cho phép sửa.
- Khi không có dữ liệu học hôm nay: hiển thị empty state và hướng dẫn hành động tiếp theo.
- Khi dữ liệu không tải được: hiển thị error state và thao tác thử lại.
- Khi phiên học hoàn thành: hiển thị success state và dẫn sang bước tiếp theo.
- Khi dùng trên màn hình nhỏ: ưu tiên nội dung học và CTA chính, không để nội dung bị che hoặc khó thao tác.

## 12. Ràng buộc và dependency

- **Nền tảng:** Mobile App ưu tiên và Web App responsive.
- **Thời gian/ngân sách/kỹ năng:** Chưa được cung cấp; cần xác nhận khi lập kế hoạch triển khai.
- **Dữ liệu:** Nội dung từ vựng HSK 1–2 là dependency quan trọng. Nguồn dữ liệu cụ thể chưa được xác định.
- **Tích hợp:** Chưa có tích hợp bên ngoài nào được xác nhận.
- **Bảo mật hoặc quyền riêng tư:** MVP cần tránh lưu hoặc log dữ liệu cá nhân không cần thiết; chi tiết cần được xác định khi triển khai.

## 13. Rủi ro và giả định

| Loại | Nội dung | Cách giảm rủi ro/kiểm chứng |
|---|---|---|
| Giả định | Người mới học thấy core flow đủ hữu ích | Cho người dùng mục tiêu thử một phiên học đầu-cuối và phỏng vấn ngắn sau đó |
| Giả định | SRS giúp người dùng quay lại ôn từ | Theo dõi việc hoàn thành phiên ôn và hỏi feedback |
| Giả định | HSK 1–2 là phạm vi phù hợp cho phiên bản đầu | Test với nhóm người mới học và xem nhu cầu mở rộng |
| Rủi ro | Nội dung từ vựng chưa có nguồn cụ thể | Chốt nguồn dữ liệu trước khi triển khai nội dung |
| Rủi ro | Thống kê có thể làm người mới bị ngợp | Chỉ hiển thị các chỉ số cần thiết cho MVP |

## 14. Câu hỏi còn mở

- [ ] Nguồn dữ liệu từ vựng HSK 1–2 sẽ được lấy từ đâu?
- [ ] Quy tắc SRS cụ thể sẽ dùng trong MVP là gì?
- [ ] Cơ chế đăng nhập/tài khoản có cần cho MVP hay không?
- [ ] Có cần lưu lịch sử học lâu dài giữa các thiết bị hay không?
- [ ] Thời gian và ngân sách triển khai MVP là bao nhiêu?

## 15. Điều kiện sẵn sàng sang Design

- [x] Một người dùng chính đã được chốt.
- [x] Một hành động chính đã được chốt.
- [x] P0 và OUT scope không mâu thuẫn.
- [x] Mỗi success criterion có cách kiểm chứng.
- [x] Giả định chưa có bằng chứng đã được đánh dấu.
- [x] Thiết bị chính và hướng trải nghiệm đã được xác định.

## Ghi chú nguồn

PRD này được xây dựng từ MVP infographic do người dùng cung cấp và các quyết định đã chốt trong hội thoại. Những thông tin chưa có trong nguồn được đánh dấu `CHƯA ĐỦ DỮ LIỆU` hoặc `Giả định`, không coi là bằng chứng đã được kiểm chứng.
